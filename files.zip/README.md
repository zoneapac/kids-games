# 🎒 PlayLearn — Kids Learning Games

A vibrant, interactive learning game app for ~7 year olds. Five mini-games, coin rewards, persistent history, and friendly explanations after every answer.

## 🎮 Games included

- 🧮 **Math Adventure** — addition, subtraction, multiplication
- 🐝 **Spelling Bee** — fill in the missing letter
- 🧠 **Memory Match** — flip-pair grid (animals, fruits, vehicles)
- 🧩 **Pattern Quest** — number, letter & shape sequences
- 🦄 **Quick Quiz** — fun trivia about animals, space, geography

## 🚀 Run locally

You need Node.js installed (https://nodejs.org — LTS version).

```bash
npm install
npm run dev
```

Open http://localhost:5173 in your browser.

## 🌐 Deploy to Vercel (free, ~3 minutes)

### Step 1 — Push to GitHub

Create a new empty repo on https://github.com (call it `kids-games`), then in this folder:

```bash
git init
git add .
git commit -m "Initial kids learning games"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/kids-games.git
git push -u origin main
```

### Step 2 — Deploy

1. Go to https://vercel.com and sign in with GitHub
2. Click **"Add New" → "Project"**
3. Find your `kids-games` repo and click **"Import"**
4. Vercel auto-detects Vite — just click **"Deploy"**
5. ~30 seconds later you'll get a public URL like `https://kids-games-yourname.vercel.app`

That's it! Share the URL with your kids on any device.

## 🌐 Alternative: Deploy to Netlify

1. Run `npm run build` (creates a `dist/` folder)
2. Go to https://app.netlify.com/drop
3. Drag the `dist/` folder onto the page
4. Done — you get a live URL

## 📱 Add to home screen on tablets/phones

Once deployed, open the URL on the device:

- **iPhone/iPad (Safari)**: tap the Share button → **"Add to Home Screen"**
- **Android (Chrome)**: tap the menu (⋮) → **"Add to Home screen"**

It'll get an icon and launch fullscreen, just like a native app.

## 💾 Data persistence

The app uses `localStorage` to save:
- Total coins earned
- Games played
- Last 50 game results

Data is stored per-device per-browser. To reset, tap the 🗑️ icon in the header (only visible on the home screen).

## ✏️ Customize content

All question banks are plain arrays at the top of `src/App.jsx`:

- `SPELLING_BANK` — words and their hints
- `QUIZ_BANK` — trivia questions and fun facts
- `PATTERN_BANK` — sequence puzzles with explanations
- `MEMORY_THEMES` — emoji sets for memory match
- `makeMathQuestions()` — math problem generator (tweak number ranges to adjust difficulty)

Edit those, save, and the dev server hot-reloads instantly.

## 🛠️ Project structure

```
kids-games/
├── index.html              # HTML entry point
├── package.json            # Dependencies
├── vite.config.js          # Build config
├── src/
│   ├── main.jsx            # React mount point
│   └── App.jsx             # The whole app (one file)
└── README.md
```

## 📜 License

MIT — yours to use, modify, and share with your kids 💛
