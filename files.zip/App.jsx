import React, { useState, useEffect, useRef } from 'react';

// =====================================================================
// CONTENT BANKS
// =====================================================================

const SPELLING_BANK = [
  { word: 'elephant', missing: [2], hint: 'A big grey animal with a long trunk' },
  { word: 'butterfly', missing: [3], hint: 'A colorful insect with pretty wings' },
  { word: 'rainbow', missing: [4], hint: 'Colors in the sky after the rain' },
  { word: 'chocolate', missing: [5], hint: 'A sweet brown treat we love' },
  { word: 'mountain', missing: [4], hint: 'A very tall piece of land' },
  { word: 'dinosaur', missing: [3], hint: 'A giant reptile from long ago' },
  { word: 'sandwich', missing: [4], hint: 'Bread with yummy fillings inside' },
  { word: 'umbrella', missing: [3], hint: 'Keeps you dry in the rain' },
  { word: 'kangaroo', missing: [4], hint: 'An animal that hops with a pouch' },
  { word: 'treasure', missing: [3], hint: 'Gold and jewels pirates hunt for' },
  { word: 'pumpkin', missing: [3], hint: 'An orange vegetable for Halloween' },
  { word: 'volcano', missing: [4], hint: 'A mountain that erupts with lava' },
];

const QUIZ_BANK = [
  { q: 'How many legs does a spider have?', choices: ['6', '8', '10', '4'], answer: 1, fact: 'Spiders are arachnids! All arachnids have 8 legs, while insects only have 6.' },
  { q: 'Which is the largest ocean on Earth?', choices: ['Atlantic', 'Indian', 'Pacific', 'Arctic'], answer: 2, fact: 'The Pacific Ocean is so big it covers more area than ALL the land on Earth combined!' },
  { q: 'How many planets are in our solar system?', choices: ['7', '8', '9', '10'], answer: 1, fact: 'There are 8 planets: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune. Pluto is now a dwarf planet!' },
  { q: 'Which organ pumps blood through our body?', choices: ['Brain', 'Heart', 'Lungs', 'Stomach'], answer: 1, fact: 'Your heart beats about 100,000 times every day without you even thinking about it!' },
  { q: 'What do you get when you mix red and yellow?', choices: ['Purple', 'Green', 'Orange', 'Pink'], answer: 2, fact: 'Red and yellow mixed make orange — like a sunset or a juicy mango!' },
  { q: 'Which animal is known as the King of the Jungle?', choices: ['Tiger', 'Lion', 'Elephant', 'Bear'], answer: 1, fact: 'A lion\'s roar can be heard from 5 miles away — that\'s really loud!' },
  { q: 'How many days are in a leap year?', choices: ['365', '366', '364', '367'], answer: 1, fact: 'Leap years happen every 4 years and have an extra day — February 29th!' },
  { q: 'What is the tallest animal in the world?', choices: ['Elephant', 'Horse', 'Giraffe', 'Camel'], answer: 2, fact: 'A giraffe can be up to 18 feet tall — that\'s like 3 grown-ups stacked on top of each other!' },
  { q: 'Which planet is closest to the Sun?', choices: ['Venus', 'Mars', 'Mercury', 'Earth'], answer: 2, fact: 'Mercury is the closest to the Sun and the smallest planet in our solar system.' },
  { q: 'How many continents are on Earth?', choices: ['5', '6', '7', '8'], answer: 2, fact: 'The 7 continents are: Africa, Antarctica, Asia, Australia, Europe, North America, and South America.' },
  { q: 'What gas do plants breathe in to make food?', choices: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Helium'], answer: 1, fact: 'Plants take in carbon dioxide and give us oxygen to breathe. Trees are amazing!' },
  { q: 'How many sides does a hexagon have?', choices: ['5', '6', '7', '8'], answer: 1, fact: 'A hexagon has 6 sides — like the cells in a beehive where bees store honey!' },
];

const PATTERN_BANK = [
  { seq: ['2', '4', '6', '8', '?'], choices: ['9', '10', '12', '11'], answer: 1, rule: 'Add 2 each time! 8 + 2 = 10. These are even numbers.' },
  { seq: ['1', '3', '5', '7', '?'], choices: ['8', '9', '10', '11'], answer: 1, rule: 'Add 2 each time! 7 + 2 = 9. These are odd numbers.' },
  { seq: ['5', '10', '15', '20', '?'], choices: ['22', '25', '30', '24'], answer: 1, rule: 'Counting by 5s! 20 + 5 = 25.' },
  { seq: ['🔴', '🔵', '🔴', '🔵', '?'], choices: ['🟢', '🔴', '🔵', '🟡'], answer: 1, rule: 'The pattern alternates: red, blue, red, blue — so red comes next!' },
  { seq: ['A', 'B', 'C', 'D', '?'], choices: ['F', 'E', 'G', 'H'], answer: 1, rule: 'The alphabet in order — D is followed by E.' },
  { seq: ['1', '4', '9', '16', '?'], choices: ['20', '25', '24', '32'], answer: 1, rule: 'These are square numbers! 1×1=1, 2×2=4, 3×3=9, 4×4=16, 5×5=25.' },
  { seq: ['10', '20', '30', '40', '?'], choices: ['45', '50', '55', '60'], answer: 1, rule: 'Counting by 10s! 40 + 10 = 50.' },
  { seq: ['⭐', '⭐⭐', '⭐⭐⭐', '?'], choices: ['⭐⭐', '⭐⭐⭐⭐', '⭐', '⭐⭐⭐⭐⭐'], answer: 1, rule: 'Add one star each time. 3 stars + 1 = 4 stars!' },
  { seq: ['3', '6', '9', '12', '?'], choices: ['14', '15', '13', '16'], answer: 1, rule: 'Counting by 3s! These are multiples of 3.' },
  { seq: ['🔺', '🔵', '🟢', '🔺', '🔵', '?'], choices: ['🔺', '🟢', '🔵', '🟡'], answer: 1, rule: 'Three shapes repeating: triangle, blue, green. After blue comes green!' },
];

const MEMORY_THEMES = {
  animals: ['🦁', '🐯', '🐸', '🦊', '🐼', '🐨', '🦒', '🐵'],
  fruits: ['🍎', '🍌', '🍇', '🍓', '🍉', '🥝', '🍊', '🥥'],
  vehicles: ['🚗', '🚂', '✈️', '🚀', '🚲', '🛵', '🚁', '⛵'],
};

// =====================================================================
// STORAGE HELPERS
// =====================================================================

const DEFAULT_PROFILE = { name: 'Champ', totalCoins: 0, gamesPlayed: 0 };

async function loadProfile() {
  try {
    const v = localStorage.getItem('kg_profile');
    return v ? JSON.parse(v) : DEFAULT_PROFILE;
  } catch { return DEFAULT_PROFILE; }
}
async function saveProfile(p) {
  try { localStorage.setItem('kg_profile', JSON.stringify(p)); } catch {}
}
async function loadHistory() {
  try {
    const v = localStorage.getItem('kg_history');
    return v ? JSON.parse(v) : [];
  } catch { return []; }
}
async function appendHistory(entry) {
  try {
    const list = await loadHistory();
    const updated = [entry, ...list].slice(0, 50);
    localStorage.setItem('kg_history', JSON.stringify(updated));
    return updated;
  } catch { return []; }
}
async function resetAll() {
  try {
    localStorage.removeItem('kg_profile');
    localStorage.removeItem('kg_history');
  } catch {}
}

// =====================================================================
// SHARED HELPERS
// =====================================================================

const shuffle = (arr) => [...arr].sort(() => Math.random() - 0.5);
const pick = (arr, n) => shuffle(arr).slice(0, n);
const rnd = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const COIN_PER_CORRECT = 10;
const STREAK_BONUS = 5;
const QUESTIONS_PER_ROUND = 5;

const GAME_META = {
  math:    { emoji: '🧮', name: 'Math Adventure',  blurb: 'Add, subtract & multiply',  bg: 'from-pink-200 to-pink-100',     accent: '#ec4899' },
  spell:   { emoji: '🐝', name: 'Spelling Bee',    blurb: 'Find the missing letter',   bg: 'from-amber-200 to-yellow-100',  accent: '#f59e0b' },
  memory:  { emoji: '🧠', name: 'Memory Match',    blurb: 'Find matching pairs',        bg: 'from-emerald-200 to-green-100', accent: '#10b981' },
  pattern: { emoji: '🧩', name: 'Pattern Quest',   blurb: 'What comes next?',           bg: 'from-sky-200 to-cyan-100',      accent: '#0ea5e9' },
  quiz:    { emoji: '🦄', name: 'Quick Quiz',      blurb: 'Fun facts & trivia',         bg: 'from-violet-200 to-purple-100', accent: '#8b5cf6' },
};

// =====================================================================
// MAIN APP
// =====================================================================

export default function App() {
  const [view, setView] = useState('home');
  const [profile, setProfile] = useState(DEFAULT_PROFILE);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNamePrompt, setShowNamePrompt] = useState(false);
  const [runKey, setRunKey] = useState(0);
  const restart = () => setRunKey((k) => k + 1);

  useEffect(() => {
    (async () => {
      const p = await loadProfile();
      const h = await loadHistory();
      setProfile(p);
      setHistory(h);
      setLoading(false);
      if (p.name === DEFAULT_PROFILE.name && p.gamesPlayed === 0) setShowNamePrompt(true);
    })();
  }, []);

  const finishRound = async ({ gameType, score, total, coinsEarned }) => {
    const updatedProfile = {
      ...profile,
      totalCoins: profile.totalCoins + coinsEarned,
      gamesPlayed: profile.gamesPlayed + 1,
    };
    setProfile(updatedProfile);
    await saveProfile(updatedProfile);
    const entry = {
      date: new Date().toISOString(),
      gameType, score, total, coinsEarned,
    };
    const newHist = await appendHistory(entry);
    setHistory(newHist);
  };

  const updateName = async (name) => {
    const trimmed = (name || '').trim().slice(0, 20) || 'Champ';
    const updated = { ...profile, name: trimmed };
    setProfile(updated);
    await saveProfile(updated);
    setShowNamePrompt(false);
  };

  const handleReset = async () => {
    if (!confirm('Reset all coins and history?')) return;
    await resetAll();
    setProfile(DEFAULT_PROFILE);
    setHistory([]);
    setShowNamePrompt(true);
  };

  return (
    <div className="kg-root">
      <style>{globalCSS}</style>

      {loading ? (
        <div className="kg-loading">Loading your treasure chest…</div>
      ) : showNamePrompt ? (
        <NamePrompt onSubmit={updateName} />
      ) : (
        <>
          <Header
            profile={profile}
            onHome={() => setView('home')}
            onHistory={() => setView('history')}
            onReset={handleReset}
            atHome={view === 'home'}
          />

          <main className="kg-main">
            {view === 'home' && <HomeScreen onPlay={(k) => setView(k)} history={history} />}
            {view === 'history' && <HistoryScreen history={history} profile={profile} />}
            {view === 'math'    && <MathGame    key={`math-${runKey}`}    onDone={(r) => finishRound({ gameType: 'math',    ...r })} onExit={() => setView('home')} onRestart={restart} />}
            {view === 'spell'   && <SpellGame   key={`spell-${runKey}`}   onDone={(r) => finishRound({ gameType: 'spell',   ...r })} onExit={() => setView('home')} onRestart={restart} />}
            {view === 'memory'  && <MemoryGame  key={`memory-${runKey}`}  onDone={(r) => finishRound({ gameType: 'memory',  ...r })} onExit={() => setView('home')} onRestart={restart} />}
            {view === 'pattern' && <PatternGame key={`pattern-${runKey}`} onDone={(r) => finishRound({ gameType: 'pattern', ...r })} onExit={() => setView('home')} onRestart={restart} />}
            {view === 'quiz'    && <QuizGame    key={`quiz-${runKey}`}    onDone={(r) => finishRound({ gameType: 'quiz',    ...r })} onExit={() => setView('home')} onRestart={restart} />}
          </main>
        </>
      )}
    </div>
  );
}

// =====================================================================
// HEADER
// =====================================================================

function Header({ profile, onHome, onHistory, onReset, atHome }) {
  return (
    <header className="kg-header">
      <button className="kg-logo" onClick={onHome}>
        <span className="kg-logo-icon">🎒</span>
        <span className="kg-logo-text">PlayLearn</span>
      </button>

      <div className="kg-header-right">
        <CoinBadge coins={profile.totalCoins} />
        <button className="kg-icon-btn" onClick={onHistory} title="History">📊</button>
        {atHome && <button className="kg-icon-btn" onClick={onReset} title="Reset">🗑️</button>}
      </div>
    </header>
  );
}

function CoinBadge({ coins }) {
  return (
    <div className="kg-coin-badge">
      <span className="kg-coin-icon">🪙</span>
      <span className="kg-coin-num">{coins}</span>
    </div>
  );
}

// =====================================================================
// NAME PROMPT
// =====================================================================

function NamePrompt({ onSubmit }) {
  const [name, setName] = useState('');
  return (
    <div className="kg-overlay">
      <div className="kg-card kg-name-card">
        <div className="kg-emoji-xl">👋</div>
        <h1 className="kg-h1">Hi friend!</h1>
        <p className="kg-p">What should we call you?</p>
        <input
          className="kg-input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Your name"
          maxLength={20}
          onKeyDown={(e) => e.key === 'Enter' && onSubmit(name)}
          autoFocus
        />
        <button className="kg-btn kg-btn-primary" onClick={() => onSubmit(name)}>
          Let's Play! 🚀
        </button>
      </div>
    </div>
  );
}

// =====================================================================
// HOME SCREEN
// =====================================================================

function HomeScreen({ onPlay, history }) {
  const bestByGame = {};
  history.forEach((h) => {
    const acc = h.total ? h.score / h.total : 0;
    if (!bestByGame[h.gameType] || acc > bestByGame[h.gameType]) bestByGame[h.gameType] = acc;
  });

  return (
    <div className="kg-home">
      <div className="kg-hero">
        <h1 className="kg-hero-title">Choose your <span className="kg-wiggle">adventure!</span></h1>
        <p className="kg-hero-sub">Pick a game, earn coins, become a champ ✨</p>
      </div>

      <div className="kg-grid">
        {Object.entries(GAME_META).map(([key, m]) => (
          <button
            key={key}
            className={`kg-game-card bg-gradient-to-br ${m.bg}`}
            style={{ '--accent': m.accent }}
            onClick={() => onPlay(key)}
          >
            <div className="kg-game-emoji">{m.emoji}</div>
            <div className="kg-game-name">{m.name}</div>
            <div className="kg-game-blurb">{m.blurb}</div>
            {bestByGame[key] !== undefined && (
              <div className="kg-game-best">⭐ Best {Math.round(bestByGame[key] * 100)}%</div>
            )}
            <div className="kg-game-play">Play →</div>
          </button>
        ))}
      </div>
    </div>
  );
}

// =====================================================================
// HISTORY SCREEN
// =====================================================================

function HistoryScreen({ history, profile }) {
  if (history.length === 0) {
    return (
      <div className="kg-empty">
        <div className="kg-emoji-xl">📭</div>
        <h2 className="kg-h2">No games yet!</h2>
        <p className="kg-p">Play a game to start your history.</p>
      </div>
    );
  }

  const totalCorrect = history.reduce((s, h) => s + h.score, 0);
  const totalQuestions = history.reduce((s, h) => s + h.total, 0);
  const accuracy = totalQuestions ? Math.round((totalCorrect / totalQuestions) * 100) : 0;

  return (
    <div className="kg-history">
      <h1 className="kg-h1">📊 Your Stats, {profile.name}!</h1>

      <div className="kg-stat-row">
        <StatCard label="Games Played" value={profile.gamesPlayed} emoji="🎮" />
        <StatCard label="Coins Earned" value={profile.totalCoins} emoji="🪙" />
        <StatCard label="Accuracy" value={`${accuracy}%`} emoji="🎯" />
      </div>

      <h2 className="kg-h2">Recent Games</h2>
      <div className="kg-history-list">
        {history.map((h, i) => {
          const m = GAME_META[h.gameType];
          const date = new Date(h.date);
          const dateStr = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) +
                          ' · ' + date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
          return (
            <div key={i} className="kg-history-item">
              <div className="kg-history-emoji">{m?.emoji || '🎮'}</div>
              <div className="kg-history-mid">
                <div className="kg-history-name">{m?.name || h.gameType}</div>
                <div className="kg-history-date">{dateStr}</div>
              </div>
              <div className="kg-history-right">
                <div className="kg-history-score">{h.score}/{h.total}</div>
                <div className="kg-history-coins">+{h.coinsEarned} 🪙</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function StatCard({ label, value, emoji }) {
  return (
    <div className="kg-stat-card">
      <div className="kg-stat-emoji">{emoji}</div>
      <div className="kg-stat-value">{value}</div>
      <div className="kg-stat-label">{label}</div>
    </div>
  );
}

// =====================================================================
// GENERIC QUIZ-STYLE GAME WRAPPER
// =====================================================================

function QuestionGame({ gameKey, questions, renderQuestion, getExplanation, onDone, onExit, onRestart }) {
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState(null);
  const [score, setScore] = useState(0);
  const [coins, setCoins] = useState(0);
  const [streak, setStreak] = useState(0);
  const [finished, setFinished] = useState(false);
  const reportedRef = useRef(false);
  const meta = GAME_META[gameKey];
  const cur = questions[idx];

  const choose = (i) => {
    if (picked !== null) return;
    setPicked(i);
    if (i === cur.answer) {
      const newStreak = streak + 1;
      let earned = COIN_PER_CORRECT;
      if (newStreak >= 3) earned += STREAK_BONUS;
      setCoins(coins + earned);
      setScore(score + 1);
      setStreak(newStreak);
    } else {
      setStreak(0);
    }
  };

  const next = () => {
    if (idx + 1 >= questions.length) {
      setFinished(true);
    } else {
      setIdx(idx + 1);
      setPicked(null);
    }
  };

  useEffect(() => {
    if (finished && !reportedRef.current) {
      reportedRef.current = true;
      onDone({ score, total: questions.length, coinsEarned: coins });
    }
  }, [finished, score, coins, onDone, questions.length]);

  if (finished) {
    return <RoundFinish gameKey={gameKey} score={score} total={questions.length} coins={coins} onExit={onExit} onAgain={onRestart} />;
  }

  const correct = picked === cur.answer;

  return (
    <div className="kg-game" style={{ '--accent': meta.accent }}>
      <div className="kg-game-header">
        <button className="kg-back" onClick={onExit}>← Back</button>
        <div className="kg-progress">
          {questions.map((_, i) => (
            <span key={i} className={`kg-dot ${i < idx ? 'done' : i === idx ? 'now' : ''}`} />
          ))}
        </div>
        <div className="kg-streak">🔥 {streak}</div>
      </div>

      <div className="kg-q-title">{meta.emoji} {meta.name}</div>

      <div className="kg-q-card">
        {renderQuestion(cur)}

        <div className="kg-choices">
          {cur.choices.map((c, i) => {
            let cls = 'kg-choice';
            if (picked !== null) {
              if (i === cur.answer) cls += ' correct';
              else if (i === picked) cls += ' wrong';
              else cls += ' dim';
            }
            return (
              <button key={i} className={cls} onClick={() => choose(i)} disabled={picked !== null}>
                {c}
              </button>
            );
          })}
        </div>

        {picked !== null && (
          <div className={`kg-feedback ${correct ? 'good' : 'bad'}`}>
            <div className="kg-feedback-head">
              {correct ? '🎉 Awesome!' : '💡 Good try!'}
              {correct && <span className="kg-coins-pop">+{COIN_PER_CORRECT}{streak >= 3 ? `+${STREAK_BONUS}🔥` : ''} 🪙</span>}
            </div>
            <div className="kg-feedback-body">{getExplanation(cur)}</div>
            <button className="kg-btn kg-btn-primary" onClick={next}>
              {idx + 1 >= questions.length ? 'See My Score 🏆' : 'Next Question →'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// =====================================================================
// END-OF-ROUND SCREEN
// =====================================================================

function RoundFinish({ gameKey, score, total, coins, onExit, onAgain }) {
  const meta = GAME_META[gameKey];
  const pct = Math.round((score / total) * 100);
  let msg, emoji;
  if (pct === 100) { msg = 'PERFECT! You\'re a superstar!'; emoji = '🌟'; }
  else if (pct >= 80) { msg = 'Amazing job!'; emoji = '🎉'; }
  else if (pct >= 60) { msg = 'Great work!'; emoji = '👏'; }
  else if (pct >= 40) { msg = 'Nice try! Keep practicing.'; emoji = '💪'; }
  else { msg = 'Don\'t give up — try again!'; emoji = '🌱'; }

  return (
    <div className="kg-finish" style={{ '--accent': meta.accent }}>
      <div className="kg-confetti">
        {[...Array(20)].map((_, i) => (
          <span key={i} className="kg-conf" style={{
            left: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 1.5}s`,
            background: ['#ec4899', '#f59e0b', '#10b981', '#0ea5e9', '#8b5cf6'][i % 5],
          }} />
        ))}
      </div>
      <div className="kg-finish-emoji">{emoji}</div>
      <h1 className="kg-h1">{msg}</h1>
      <div className="kg-finish-score">
        <div className="kg-finish-num">{score}<span>/{total}</span></div>
        <div className="kg-finish-coins">+{coins} 🪙</div>
      </div>
      <div className="kg-finish-actions">
        <button className="kg-btn kg-btn-secondary" onClick={onExit}>🏠 Home</button>
        <button className="kg-btn kg-btn-primary" onClick={onAgain}>🔁 Play Again</button>
      </div>
    </div>
  );
}

// =====================================================================
// MATH GAME (auto-generated questions)
// =====================================================================

function makeMathQuestions(count = QUESTIONS_PER_ROUND) {
  const ops = ['+', '-', '×'];
  const out = [];
  while (out.length < count) {
    const op = ops[rnd(0, 2)];
    let a, b, answer;
    if (op === '+') { a = rnd(2, 20); b = rnd(2, 20); answer = a + b; }
    else if (op === '-') { a = rnd(5, 25); b = rnd(1, a - 1); answer = a - b; }
    else { a = rnd(2, 9); b = rnd(2, 9); answer = a * b; }
    const wrongs = new Set();
    while (wrongs.size < 3) {
      const delta = rnd(-5, 5);
      const w = answer + (delta === 0 ? 1 : delta);
      if (w !== answer && w >= 0) wrongs.add(w);
    }
    const choices = shuffle([answer, ...wrongs]);
    out.push({
      a, b, op, answer: choices.indexOf(answer),
      choices: choices.map(String),
      truthValue: answer,
    });
  }
  return out;
}

function MathGame({ onDone, onExit, onRestart }) {
  const [questions] = useState(() => makeMathQuestions());
  return (
    <QuestionGame
      gameKey="math"
      questions={questions}
      onDone={onDone}
      onExit={onExit}
      onRestart={onRestart}
      renderQuestion={(q) => (
        <div className="kg-math-q">
          <span className="kg-math-num">{q.a}</span>
          <span className="kg-math-op">{q.op}</span>
          <span className="kg-math-num">{q.b}</span>
          <span className="kg-math-op">=</span>
          <span className="kg-math-num">?</span>
        </div>
      )}
      getExplanation={(q) => {
        if (q.op === '+') return `Add them up: ${q.a} + ${q.b} = ${q.truthValue}. Tip: count up from the bigger number!`;
        if (q.op === '-') return `Take away: ${q.a} − ${q.b} = ${q.truthValue}. Tip: imagine starting with ${q.a} apples and giving away ${q.b}.`;
        return `Multiply: ${q.a} × ${q.b} = ${q.truthValue}. Tip: that's ${q.a} groups of ${q.b}, all added together!`;
      }}
    />
  );
}

// =====================================================================
// SPELLING GAME
// =====================================================================

function makeSpellQuestions() {
  return pick(SPELLING_BANK, QUESTIONS_PER_ROUND).map((item) => {
    const idx = item.missing[0];
    const correctLetter = item.word[idx];
    const others = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','r','s','t','u','y']
      .filter((l) => l !== correctLetter);
    const wrongs = pick(others, 3);
    const choices = shuffle([correctLetter, ...wrongs]);
    return {
      word: item.word,
      missingIdx: idx,
      hint: item.hint,
      choices,
      answer: choices.indexOf(correctLetter),
      correctLetter,
    };
  });
}

function SpellGame({ onDone, onExit, onRestart }) {
  const [questions] = useState(() => makeSpellQuestions());
  return (
    <QuestionGame
      gameKey="spell"
      questions={questions}
      onDone={onDone}
      onExit={onExit}
      onRestart={onRestart}
      renderQuestion={(q) => (
        <div>
          <div className="kg-spell-word">
            {q.word.split('').map((ch, i) => (
              <span key={i} className={`kg-spell-letter ${i === q.missingIdx ? 'blank' : ''}`}>
                {i === q.missingIdx ? '_' : ch}
              </span>
            ))}
          </div>
          <div className="kg-spell-hint">💭 {q.hint}</div>
        </div>
      )}
      getExplanation={(q) => `The missing letter is "${q.correctLetter}" — the word is "${q.word.toUpperCase()}". ${q.hint}.`}
    />
  );
}

// =====================================================================
// PATTERN GAME
// =====================================================================

function PatternGame({ onDone, onExit, onRestart }) {
  const [questions] = useState(() => pick(PATTERN_BANK, QUESTIONS_PER_ROUND));
  return (
    <QuestionGame
      gameKey="pattern"
      questions={questions}
      onDone={onDone}
      onExit={onExit}
      onRestart={onRestart}
      renderQuestion={(q) => (
        <div className="kg-pattern-row">
          {q.seq.map((s, i) => (
            <span key={i} className={`kg-pattern-cell ${s === '?' ? 'unknown' : ''}`}>{s}</span>
          ))}
        </div>
      )}
      getExplanation={(q) => q.rule}
    />
  );
}

// =====================================================================
// QUIZ GAME
// =====================================================================

function QuizGame({ onDone, onExit, onRestart }) {
  const [questions] = useState(() => pick(QUIZ_BANK, QUESTIONS_PER_ROUND));
  return (
    <QuestionGame
      gameKey="quiz"
      questions={questions}
      onDone={onDone}
      onExit={onExit}
      onRestart={onRestart}
      renderQuestion={(q) => <div className="kg-quiz-q">{q.q}</div>}
      getExplanation={(q) => `${q.choices[q.answer]} is correct! ${q.fact}`}
    />
  );
}

// =====================================================================
// MEMORY MATCH GAME
// =====================================================================

function MemoryGame({ onDone, onExit, onRestart }) {
  const themeKeys = Object.keys(MEMORY_THEMES);
  const [theme] = useState(() => themeKeys[rnd(0, themeKeys.length - 1)]);
  const [cards] = useState(() => {
    const items = MEMORY_THEMES[theme];
    return shuffle([...items, ...items].map((emoji, i) => ({ id: i, emoji })));
  });
  const [flipped, setFlipped] = useState([]);
  const [matched, setMatched] = useState(new Set());
  const [attempts, setAttempts] = useState(0);
  const [done, setDone] = useState(false);
  const [coinsEarned, setCoinsEarned] = useState(0);
  const reportedRef = useRef(false);

  const flip = (i) => {
    if (flipped.length >= 2) return;
    if (flipped.includes(i) || matched.has(i)) return;
    const next = [...flipped, i];
    setFlipped(next);
    if (next.length === 2) {
      setAttempts(attempts + 1);
      const [a, b] = next;
      if (cards[a].emoji === cards[b].emoji) {
        setTimeout(() => {
          setMatched((m) => {
            const nm = new Set(m); nm.add(a); nm.add(b); return nm;
          });
          setFlipped([]);
        }, 600);
      } else {
        setTimeout(() => setFlipped([]), 1000);
      }
    }
  };

  useEffect(() => {
    if (matched.size === cards.length && !reportedRef.current) {
      reportedRef.current = true;
      const pairs = cards.length / 2;
      const efficiency = Math.max(0, Math.min(1, pairs / Math.max(attempts, 1)));
      const earned = Math.round(40 + efficiency * 60); // 40-100 coins
      setCoinsEarned(earned);
      setDone(true);
      onDone({ score: pairs, total: pairs, coinsEarned: earned });
    }
  }, [matched, cards.length, attempts, onDone]);

  if (done) {
    const pairs = cards.length / 2;
    return (
      <RoundFinish
        gameKey="memory"
        score={pairs}
        total={pairs}
        coins={coinsEarned}
        onExit={onExit}
        onAgain={onRestart}
      />
    );
  }

  return (
    <div className="kg-game" style={{ '--accent': GAME_META.memory.accent }}>
      <div className="kg-game-header">
        <button className="kg-back" onClick={onExit}>← Back</button>
        <div className="kg-mem-stats">
          <span>🎯 {matched.size / 2}/{cards.length / 2}</span>
          <span>🔄 {attempts}</span>
        </div>
      </div>
      <div className="kg-q-title">🧠 Memory Match — {theme}</div>
      <p className="kg-mem-hint">Find all matching pairs!</p>

      <div className="kg-mem-grid">
        {cards.map((c, i) => {
          const isUp = flipped.includes(i) || matched.has(i);
          const isMatched = matched.has(i);
          return (
            <button
              key={c.id}
              className={`kg-mem-card ${isUp ? 'up' : ''} ${isMatched ? 'matched' : ''}`}
              onClick={() => flip(i)}
              disabled={isMatched}
            >
              <span className="kg-mem-back">?</span>
              <span className="kg-mem-front">{c.emoji}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// =====================================================================
// STYLES
// =====================================================================

const globalCSS = `
@import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@400;500;600;700&family=Nunito:wght@600;700;800&display=swap');

.kg-root {
  min-height: 100vh;
  background:
    radial-gradient(circle at 10% 10%, #fff5d4 0%, transparent 40%),
    radial-gradient(circle at 90% 20%, #ffd6e8 0%, transparent 40%),
    radial-gradient(circle at 80% 90%, #d4f1ff 0%, transparent 40%),
    linear-gradient(180deg, #fffaf0 0%, #fff0f5 100%);
  font-family: 'Nunito', sans-serif;
  color: #2d1b3a;
  padding: 0 0 40px;
  position: relative;
  overflow-x: hidden;
}
.kg-root::before {
  content: '';
  position: fixed; inset: 0;
  background-image: radial-gradient(circle at 1px 1px, rgba(45,27,58,0.05) 1px, transparent 0);
  background-size: 24px 24px;
  pointer-events: none;
  z-index: 0;
}
.kg-root > * { position: relative; z-index: 1; }

.kg-loading {
  display: flex; align-items: center; justify-content: center;
  height: 100vh; font-family: 'Fredoka', sans-serif; font-size: 1.5rem; color: #ec4899;
}

/* HEADER */
.kg-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 16px 20px;
  position: sticky; top: 0; z-index: 10;
  backdrop-filter: blur(10px);
  background: rgba(255, 250, 240, 0.85);
  border-bottom: 2px dashed rgba(236, 72, 153, 0.2);
}
.kg-logo {
  display: flex; align-items: center; gap: 8px;
  background: none; border: none; cursor: pointer;
  font-family: 'Fredoka', sans-serif; font-size: 1.4rem; font-weight: 700;
  color: #2d1b3a; padding: 4px 8px; border-radius: 12px;
  transition: transform 0.2s;
}
.kg-logo:hover { transform: rotate(-2deg) scale(1.05); }
.kg-logo-icon { font-size: 1.8rem; }
.kg-logo-text { background: linear-gradient(135deg, #ec4899, #f59e0b); -webkit-background-clip: text; background-clip: text; color: transparent; }

.kg-header-right { display: flex; align-items: center; gap: 10px; }

.kg-coin-badge {
  display: flex; align-items: center; gap: 6px;
  background: linear-gradient(135deg, #fef3c7, #fcd34d);
  padding: 6px 14px; border-radius: 20px;
  border: 2px solid #f59e0b;
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  box-shadow: 0 3px 0 #d97706;
}
.kg-coin-icon { font-size: 1.2rem; }
.kg-coin-num { font-size: 1.1rem; color: #78350f; min-width: 20px; text-align: right; }

.kg-icon-btn {
  background: white; border: 2px solid #e5d0e8;
  width: 40px; height: 40px; border-radius: 50%;
  font-size: 1.2rem; cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 2px 0 #c5a5cf;
}
.kg-icon-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 0 #c5a5cf; }
.kg-icon-btn:active { transform: translateY(2px); box-shadow: 0 0 0 #c5a5cf; }

/* MAIN */
.kg-main { max-width: 900px; margin: 0 auto; padding: 24px 20px; }

/* HOME */
.kg-hero { text-align: center; margin-bottom: 32px; }
.kg-hero-title {
  font-family: 'Fredoka', sans-serif; font-weight: 700;
  font-size: clamp(2rem, 5vw, 3rem); margin: 0 0 8px;
  color: #2d1b3a;
}
.kg-wiggle {
  display: inline-block;
  background: linear-gradient(135deg, #ec4899, #8b5cf6);
  -webkit-background-clip: text; background-clip: text; color: transparent;
  animation: wiggle 2s ease-in-out infinite;
}
@keyframes wiggle {
  0%, 100% { transform: rotate(-3deg); }
  50% { transform: rotate(3deg); }
}
.kg-hero-sub { font-size: 1.05rem; color: #6b4f7c; margin: 0; }

.kg-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 16px;
}

.kg-game-card {
  position: relative;
  border: 3px solid var(--accent);
  border-radius: 24px;
  padding: 24px 20px 20px;
  cursor: pointer; text-align: left;
  font-family: 'Nunito', sans-serif;
  box-shadow: 0 6px 0 var(--accent), 0 12px 24px rgba(45, 27, 58, 0.08);
  transition: all 0.2s ease;
  overflow: hidden;
}
.kg-game-card:hover {
  transform: translateY(-4px) rotate(-1deg);
  box-shadow: 0 10px 0 var(--accent), 0 18px 30px rgba(45, 27, 58, 0.12);
}
.kg-game-card:active {
  transform: translateY(2px);
  box-shadow: 0 4px 0 var(--accent);
}
.kg-game-card::before {
  content: '';
  position: absolute; top: -20px; right: -20px;
  width: 80px; height: 80px;
  background: var(--accent); opacity: 0.1;
  border-radius: 50%;
}
.kg-game-emoji {
  font-size: 3rem; line-height: 1;
  margin-bottom: 12px; display: inline-block;
  filter: drop-shadow(2px 2px 0 rgba(0,0,0,0.1));
  transition: transform 0.3s;
}
.kg-game-card:hover .kg-game-emoji { transform: rotate(15deg) scale(1.15); }
.kg-game-name {
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  font-size: 1.25rem; color: #2d1b3a; margin-bottom: 4px;
}
.kg-game-blurb { font-size: 0.9rem; color: #6b4f7c; margin-bottom: 12px; }
.kg-game-best {
  display: inline-block; background: white; padding: 4px 10px;
  border-radius: 12px; font-size: 0.8rem; font-weight: 700;
  color: var(--accent); margin-bottom: 8px;
  border: 2px solid var(--accent);
}
.kg-game-play {
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  color: var(--accent); font-size: 1rem;
}

/* GAME COMMON */
.kg-game { max-width: 700px; margin: 0 auto; }
.kg-game-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 20px;
}
.kg-back {
  background: white; border: 2px solid var(--accent, #ec4899);
  padding: 8px 14px; border-radius: 16px;
  font-family: 'Fredoka', sans-serif; font-weight: 500;
  cursor: pointer; color: var(--accent, #ec4899);
  box-shadow: 0 3px 0 var(--accent, #ec4899);
  transition: all 0.15s;
}
.kg-back:hover { transform: translateY(-1px); }
.kg-back:active { transform: translateY(2px); box-shadow: 0 0 0 var(--accent, #ec4899); }

.kg-progress { display: flex; gap: 6px; }
.kg-dot {
  width: 12px; height: 12px; border-radius: 50%;
  background: rgba(45, 27, 58, 0.15);
  transition: all 0.3s;
}
.kg-dot.done { background: var(--accent, #ec4899); }
.kg-dot.now {
  background: var(--accent, #ec4899);
  transform: scale(1.4);
  box-shadow: 0 0 0 4px rgba(236, 72, 153, 0.2);
}

.kg-streak {
  background: linear-gradient(135deg, #fef3c7, #fcd34d);
  padding: 4px 10px; border-radius: 12px;
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  border: 2px solid #f59e0b; font-size: 0.9rem;
}

.kg-q-title {
  font-family: 'Fredoka', sans-serif; font-size: 1.1rem;
  font-weight: 600; color: var(--accent, #2d1b3a);
  text-align: center; margin-bottom: 16px;
}

.kg-q-card {
  background: white;
  border: 3px solid var(--accent, #ec4899);
  border-radius: 28px; padding: 32px 24px;
  box-shadow: 0 6px 0 var(--accent, #ec4899);
}

.kg-choices {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px; margin-top: 24px;
}
.kg-choice {
  background: white;
  border: 3px solid #e5d0e8;
  border-radius: 18px;
  padding: 18px 16px;
  font-family: 'Fredoka', sans-serif;
  font-size: 1.3rem; font-weight: 500;
  cursor: pointer; color: #2d1b3a;
  box-shadow: 0 4px 0 #c5a5cf;
  transition: all 0.15s;
}
.kg-choice:hover:not(:disabled) {
  transform: translateY(-2px);
  border-color: var(--accent, #ec4899);
  box-shadow: 0 6px 0 var(--accent, #ec4899);
}
.kg-choice:active:not(:disabled) { transform: translateY(2px); box-shadow: 0 2px 0 #c5a5cf; }
.kg-choice.correct {
  background: linear-gradient(135deg, #d1fae5, #a7f3d0);
  border-color: #10b981; color: #064e3b;
  box-shadow: 0 4px 0 #059669;
  animation: bounce-correct 0.5s;
}
.kg-choice.wrong {
  background: linear-gradient(135deg, #fee2e2, #fecaca);
  border-color: #ef4444; color: #7f1d1d;
  box-shadow: 0 4px 0 #dc2626;
  animation: shake 0.4s;
}
.kg-choice.dim { opacity: 0.4; }

@keyframes bounce-correct {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.08); }
}
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-6px); }
  75% { transform: translateX(6px); }
}

.kg-feedback {
  margin-top: 24px; padding: 18px 20px;
  border-radius: 18px;
  animation: pop-in 0.4s ease-out;
}
.kg-feedback.good { background: linear-gradient(135deg, #d1fae5, #ecfccb); border: 2px solid #10b981; }
.kg-feedback.bad { background: linear-gradient(135deg, #fef3c7, #fee2e2); border: 2px solid #f59e0b; }
.kg-feedback-head {
  display: flex; justify-content: space-between; align-items: center;
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  font-size: 1.15rem; margin-bottom: 8px;
}
.kg-coins-pop {
  background: white; padding: 4px 10px; border-radius: 12px;
  border: 2px solid #f59e0b; color: #78350f;
  animation: coin-pop 0.5s ease-out;
}
@keyframes coin-pop {
  0% { transform: scale(0); }
  60% { transform: scale(1.3); }
  100% { transform: scale(1); }
}
.kg-feedback-body {
  font-size: 0.98rem; line-height: 1.5;
  color: #4a3458; margin-bottom: 14px;
}
@keyframes pop-in {
  0% { transform: scale(0.9); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}

/* BUTTONS */
.kg-btn {
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  border-radius: 16px; padding: 12px 24px;
  font-size: 1.05rem; cursor: pointer;
  transition: all 0.15s; border: none;
}
.kg-btn-primary {
  background: linear-gradient(135deg, #ec4899, #f43f5e);
  color: white;
  box-shadow: 0 4px 0 #be185d;
}
.kg-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 6px 0 #be185d; }
.kg-btn-primary:active { transform: translateY(2px); box-shadow: 0 2px 0 #be185d; }
.kg-btn-secondary {
  background: white; color: #2d1b3a;
  border: 2px solid #e5d0e8;
  box-shadow: 0 4px 0 #c5a5cf;
}
.kg-btn-secondary:hover { transform: translateY(-2px); box-shadow: 0 6px 0 #c5a5cf; }
.kg-btn-secondary:active { transform: translateY(2px); box-shadow: 0 2px 0 #c5a5cf; }

/* MATH */
.kg-math-q {
  display: flex; justify-content: center; align-items: center;
  gap: 12px; flex-wrap: wrap;
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  font-size: 3rem; color: #2d1b3a;
}
.kg-math-num {
  background: linear-gradient(135deg, #fce7f3, #fbcfe8);
  padding: 10px 18px; border-radius: 16px;
  border: 3px solid #ec4899; min-width: 60px; text-align: center;
  box-shadow: 0 4px 0 #be185d;
}
.kg-math-op { color: #ec4899; }

/* SPELL */
.kg-spell-word {
  display: flex; justify-content: center; gap: 6px;
  flex-wrap: wrap;
  font-family: 'Fredoka', sans-serif; font-size: 2.5rem;
  font-weight: 600; color: #78350f;
  margin-bottom: 16px;
}
.kg-spell-letter {
  display: inline-block;
  padding: 6px 12px; border-radius: 12px;
  background: #fef3c7; min-width: 36px; text-align: center;
  text-transform: uppercase;
}
.kg-spell-letter.blank {
  background: white; border: 3px dashed #f59e0b;
  color: #f59e0b;
}
.kg-spell-hint {
  text-align: center; font-size: 1.05rem; color: #78350f;
  background: #fffbeb; padding: 10px 14px; border-radius: 12px;
  border: 2px solid #fcd34d;
}

/* PATTERN */
.kg-pattern-row {
  display: flex; justify-content: center; gap: 10px;
  flex-wrap: wrap;
}
.kg-pattern-cell {
  background: linear-gradient(135deg, #cffafe, #a5f3fc);
  border: 3px solid #0ea5e9; border-radius: 16px;
  padding: 14px 18px; min-width: 56px;
  font-family: 'Fredoka', sans-serif;
  font-size: 2rem; font-weight: 600;
  color: #0c4a6e; text-align: center;
  box-shadow: 0 4px 0 #0369a1;
}
.kg-pattern-cell.unknown {
  background: white; border-style: dashed; color: #0ea5e9;
}

/* QUIZ */
.kg-quiz-q {
  font-family: 'Fredoka', sans-serif; font-size: 1.5rem;
  font-weight: 500; color: #2d1b3a; text-align: center;
  line-height: 1.4;
}

/* MEMORY */
.kg-mem-stats {
  display: flex; gap: 12px;
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  font-size: 1rem;
}
.kg-mem-hint { text-align: center; color: #6b4f7c; margin: 0 0 16px; }
.kg-mem-grid {
  display: grid; grid-template-columns: repeat(4, 1fr);
  gap: 10px; max-width: 400px; margin: 0 auto;
}
.kg-mem-card {
  position: relative;
  aspect-ratio: 1;
  border: none; padding: 0;
  background: transparent;
  cursor: pointer;
  perspective: 600px;
}
.kg-mem-back, .kg-mem-front {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  border-radius: 16px;
  font-family: 'Fredoka', sans-serif;
  font-weight: 700;
  backface-visibility: hidden;
  transition: transform 0.5s;
}
.kg-mem-back {
  background: linear-gradient(135deg, #10b981, #059669);
  color: white; font-size: 2rem;
  box-shadow: 0 4px 0 #047857;
}
.kg-mem-front {
  background: white; border: 3px solid #10b981;
  font-size: 2.5rem;
  transform: rotateY(180deg);
  box-shadow: 0 4px 0 #059669;
}
.kg-mem-card.up .kg-mem-back { transform: rotateY(180deg); }
.kg-mem-card.up .kg-mem-front { transform: rotateY(0); }
.kg-mem-card.matched .kg-mem-front {
  background: linear-gradient(135deg, #d1fae5, #a7f3d0);
  animation: matched-pop 0.5s;
}
@keyframes matched-pop {
  0% { transform: rotateY(0) scale(1); }
  50% { transform: rotateY(0) scale(1.15); }
  100% { transform: rotateY(0) scale(1); }
}

/* FINISH SCREEN */
.kg-finish {
  max-width: 500px; margin: 40px auto;
  text-align: center; padding: 32px 24px;
  background: white;
  border: 3px solid var(--accent, #ec4899);
  border-radius: 32px;
  box-shadow: 0 8px 0 var(--accent, #ec4899);
  position: relative; overflow: hidden;
}
.kg-finish-emoji {
  font-size: 5rem;
  animation: bounce-big 1s ease-in-out infinite;
}
@keyframes bounce-big {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-12px); }
}
.kg-finish-score {
  display: flex; justify-content: center; gap: 24px;
  margin: 24px 0;
}
.kg-finish-num {
  font-family: 'Fredoka', sans-serif; font-weight: 700;
  font-size: 4rem; color: var(--accent, #ec4899);
  line-height: 1;
}
.kg-finish-num span { font-size: 2rem; color: #6b4f7c; }
.kg-finish-coins {
  font-family: 'Fredoka', sans-serif; font-weight: 700;
  font-size: 2rem; color: #f59e0b;
  align-self: center;
  background: #fef3c7; padding: 8px 16px; border-radius: 16px;
  border: 2px solid #f59e0b;
}
.kg-finish-actions {
  display: flex; gap: 12px; justify-content: center;
  flex-wrap: wrap;
}

.kg-confetti {
  position: absolute; inset: 0; pointer-events: none;
  overflow: hidden;
}
.kg-conf {
  position: absolute; top: -10px;
  width: 10px; height: 10px;
  border-radius: 2px;
  animation: fall 2.5s linear infinite;
}
@keyframes fall {
  0% { transform: translateY(0) rotate(0); opacity: 1; }
  100% { transform: translateY(600px) rotate(720deg); opacity: 0; }
}

/* HISTORY */
.kg-h1 {
  font-family: 'Fredoka', sans-serif; font-weight: 700;
  font-size: 2rem; margin: 0 0 16px; color: #2d1b3a;
  text-align: center;
}
.kg-h2 {
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  font-size: 1.4rem; margin: 24px 0 12px; color: #2d1b3a;
}
.kg-p { color: #6b4f7c; line-height: 1.5; }

.kg-stat-row {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 12px; margin-bottom: 24px;
}
.kg-stat-card {
  background: white; border: 3px solid #e5d0e8;
  border-radius: 20px; padding: 16px 12px;
  text-align: center;
  box-shadow: 0 4px 0 #c5a5cf;
}
.kg-stat-emoji { font-size: 2rem; }
.kg-stat-value {
  font-family: 'Fredoka', sans-serif; font-weight: 700;
  font-size: 1.5rem; color: #ec4899; margin: 4px 0;
}
.kg-stat-label { font-size: 0.85rem; color: #6b4f7c; }

.kg-history-list { display: flex; flex-direction: column; gap: 8px; }
.kg-history-item {
  display: flex; align-items: center; gap: 14px;
  background: white; border: 2px solid #e5d0e8;
  border-radius: 16px; padding: 12px 16px;
  box-shadow: 0 3px 0 #c5a5cf;
}
.kg-history-emoji { font-size: 2rem; }
.kg-history-mid { flex: 1; min-width: 0; }
.kg-history-name {
  font-family: 'Fredoka', sans-serif; font-weight: 600;
  font-size: 1.05rem; color: #2d1b3a;
}
.kg-history-date { font-size: 0.85rem; color: #6b4f7c; }
.kg-history-right { text-align: right; }
.kg-history-score {
  font-family: 'Fredoka', sans-serif; font-weight: 700;
  font-size: 1.1rem; color: #ec4899;
}
.kg-history-coins { font-size: 0.85rem; color: #d97706; font-weight: 700; }

.kg-empty {
  text-align: center; padding: 60px 20px;
}
.kg-emoji-xl { font-size: 5rem; margin-bottom: 12px; }

/* OVERLAY (name prompt) */
.kg-overlay {
  position: fixed; inset: 0;
  display: flex; align-items: center; justify-content: center;
  background: rgba(45, 27, 58, 0.4); backdrop-filter: blur(8px);
  z-index: 100; padding: 20px;
}
.kg-card {
  background: white; border-radius: 28px;
  padding: 32px 28px; max-width: 380px; width: 100%;
  text-align: center;
  border: 3px solid #ec4899;
  box-shadow: 0 8px 0 #ec4899, 0 16px 40px rgba(0,0,0,0.2);
}
.kg-name-card .kg-h1 { margin: 12px 0 8px; }

.kg-input {
  width: 100%; box-sizing: border-box;
  padding: 14px 18px; font-size: 1.1rem;
  border: 3px solid #e5d0e8; border-radius: 16px;
  font-family: 'Nunito', sans-serif; font-weight: 600;
  margin: 16px 0;
  outline: none; transition: border-color 0.2s;
}
.kg-input:focus { border-color: #ec4899; }

/* RESPONSIVE */
@media (max-width: 480px) {
  .kg-grid { grid-template-columns: 1fr; }
  .kg-stat-row { grid-template-columns: 1fr; gap: 8px; }
  .kg-stat-card { display: flex; align-items: center; gap: 12px; text-align: left; padding: 12px 16px; }
  .kg-stat-emoji { font-size: 1.5rem; }
  .kg-math-q { font-size: 2.2rem; }
  .kg-spell-word { font-size: 1.8rem; }
  .kg-finish-num { font-size: 3rem; }
  .kg-finish-coins { font-size: 1.5rem; }
  .kg-mem-grid { gap: 8px; }
  .kg-mem-back { font-size: 1.5rem; }
  .kg-mem-front { font-size: 2rem; }
}
`;
